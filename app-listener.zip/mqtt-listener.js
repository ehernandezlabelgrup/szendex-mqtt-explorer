const mqtt = require('mqtt');

// Configuración del broker MQTT
const MQTT_CONFIG = {
  host: 'ingestaprod.thesmartdelivery.com',
  port: 1883,
  username: 'verneAgent',
  password: 'LOIGK3xsdSGLJ',
  clientId: `mqtt_listener_${Math.random().toString(16).slice(3)}`
};

// Topics a escuchar
const TOPICS = [
  'cooler_mqtt/ics/#'
];

console.log('🚀 Iniciando cliente MQTT...');
console.log(`📡 Conectando a: ${MQTT_CONFIG.host}:${MQTT_CONFIG.port}`);

// Crear cliente MQTT
const client = mqtt.connect(`mqtt://${MQTT_CONFIG.host}:${MQTT_CONFIG.port}`, {
  username: MQTT_CONFIG.username,
  password: MQTT_CONFIG.password,
  clientId: MQTT_CONFIG.clientId,
  clean: true,
  reconnectPeriod: 5000,
  connectTimeout: 30000
});

// Evento: Conexión exitosa
client.on('connect', () => {
  console.log('✅ Conectado al broker MQTT');
  
  // Suscribirse a los topics
  TOPICS.forEach(topic => {
    client.subscribe(topic, (err) => {
      if (err) {
        console.error(`❌ Error al suscribirse a ${topic}:`, err.message);
      } else {
        console.log(`📬 Suscrito a: ${topic}`);
      }
    });
  });
  
  console.log('👂 Escuchando mensajes...\n');
});

// Evento: Mensaje recibido
client.on('message', (topic, message) => {
  const timestamp = new Date().toISOString();
  const payload = message.toString();
  
  console.log('─────────────────────────────────────────');
  console.log(`⏰ Timestamp: ${timestamp}`);
  console.log(`📍 Topic: ${topic}`);
  console.log(`📦 Mensaje:`);
  
  // Intentar parsear como JSON
  try {
    const jsonData = JSON.parse(payload);
    console.log(JSON.stringify(jsonData, null, 2));
  } catch (e) {
    // Si no es JSON, mostrar como texto
    console.log(payload);
  }
  
  console.log('─────────────────────────────────────────\n');
});

// Evento: Error
client.on('error', (error) => {
  console.error('❌ Error en conexión MQTT:', error.message);
});

// Evento: Reconexión
client.on('reconnect', () => {
  console.log('🔄 Intentando reconectar...');
});

// Evento: Desconexión
client.on('close', () => {
  console.log('🔌 Desconectado del broker MQTT');
});

// Evento: Offline
client.on('offline', () => {
  console.log('📴 Cliente MQTT offline');
});

// Manejo de señales para cerrar limpiamente
process.on('SIGINT', () => {
  console.log('\n\n👋 Cerrando conexión...');
  client.end();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n\n👋 Cerrando conexión...');
  client.end();
  process.exit(0);
});
